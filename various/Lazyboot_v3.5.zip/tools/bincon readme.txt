0WINCEOS.BIN -> 1ST_READ.BIN Converter v1
  
usage: bincon <0WINCEOS.BIN file> <new 1ST_READ.BIN to create>
example: bincon 0WINCEOS.BIN 1ST_READ.BIN

It does what it says it does. It allows you to run DC WinCE apps with
Utopia's Boot Disc v1.1. I gave the option of naming the file names 
just incase someone didn't want them to have the exact names. 

Tested on: Midway Aracde Classics - works 100%
	   Sega Rally 2 - works 100%
           Rearview Mirror WinCE Dev Kit Demo - works 100%

The exe is a win32 exe that was compiled by DJGPP in Windows 2000. 
The source should compile under any OS.

Source released under the GNU General Public License:
http://www.fsf.org/copyleft/gpl.html

One last thing: I give NO SUPPORT with this program. If it doesn't work
for you, you're screwing something up. This program is meant for
development purposes only: port an emulator, write a vcd player, etc.
I'm not responsible if you use this for anything illegal.

Thanks to: -Utopia for the boot disc; we wouldn't be here without them.
           -Kalisto for cracking the first WinCE games; I couldn't 
            have written this without that.
           -LITTLE MILTON and BRITTA'S FITTA (you know who you are)
            for code tricks and figuring out why dos was being gay. 

by dopefish on 7/28/00
contact_dopefish@hotmail.com for serious comments/bug reports ONLY.