Lazyboot 3.5. Mini readme:

This is a script that can create selfboot images for Dreamcast. 
Many features are not available (this is a light version).

System requirement: WinXP is not supported since v4. Use Win7 or newer.

----------------------------

How to use:

1. copy files from GDI (use GDI Explorer to extract) to "data" folder.
2. run Lazyboot_v3.5.cmd or Lazyboot.exe, if you like it.
3. select image format. If you don't know what to choose, select the first one and press Enter several times.

----------------------------

FAQ:

Q: my image is not boot
A: try to delete IP.BIN from "data" to use a generic one or vise versa, use use GDI Explorer to extract the original one and use it.
Use "IP.BIN 4 Win.exe" to change parameters.

----------------------------

Notes:

For homebrew (KOS) games you need to disable binhack.
For GDI you need to provide an original IP.BIN and 1ST_READ.BIN (or patch unoriginal 1ST_READ.BIN to LBA45000 via BinPATCH.exe).

Lazyboot can create images with emulators or video. Copy ROMs or mp4 videos to "roms" folder.
