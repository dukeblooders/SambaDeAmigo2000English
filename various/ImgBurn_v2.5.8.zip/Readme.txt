1. Launch ImgBurn
2. Select "Write image file to disc"
3. Source: select the .CDI file
4. Set "Write Speed" to minimum (2x)
5. Click "Write" button
6. Enjoy!